/**
 * POST /api/admin/publish-chapter
 *
 * Adds a new chapter to an existing novel and bumps the novel's
 * latestChapterNumber + updatedAt for sitemap freshness.
 *
 * Body: {
 *   novelId, title, content, chapterNumber,
 *   isVip?: boolean (default false for chapter 1-2, true otherwise),
 *   price?: number (default 50 if VIP),
 *   aiAssisted?: boolean
 * }
 *
 * Auth: verified admin user or server-only machine token.
 * DB: Firebase Admin SDK — bypasses Firestore security rules.
 */
import { NextRequest, NextResponse } from 'next/server';
import { authorizeAdmin } from '@/lib/apiAuth';
import { adminDb, serverTimestamp } from '@/lib/firebaseAdmin';

export const runtime = 'nodejs';
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  const auth = await authorizeAdmin(req);
  if (!auth.ok) return NextResponse.json({ error: auth.reason }, { status: auth.status || 401 });

  try {
    const body = await req.json();
    const {
      novelId,
      title,
      content,
      chapterNumber,
      isVip,
      price,
      aiAssisted = true,
    } = body;

    if (!novelId || !title || !content || !chapterNumber) {
      return NextResponse.json(
        { error: 'Missing novelId / title / content / chapterNumber' },
        { status: 400 }
      );
    }

    const num = Number(chapterNumber);
    // Default policy: chapters 1-3 are free, 4+ are VIP at 50 coins
    const finalIsVip = typeof isVip === 'boolean' ? isVip : num >= 4;
    const finalPrice = finalIsVip ? Number(price) || 50 : 0;

    const chapterId = `c${num}`;
    const chapterDoc = {
      id: chapterId,
      title,
      content,
      chapterNumber: num,
      isVip: finalIsVip,
      price: finalPrice,
      publishDate: serverTimestamp(),
      aiAssisted,
    };

    const db = adminDb();
    const batch = db.batch();
    batch.set(db.doc(`novels/${novelId}/chapters/${chapterId}`), chapterDoc);
    batch.update(db.doc(`novels/${novelId}`), {
      latestChapterNumber: num,
      updatedAt: serverTimestamp(),
      lastUpdated: new Date().toISOString(),
    });

    await batch.commit();

    return NextResponse.json({ ok: true, chapterId, isVip: finalIsVip, price: finalPrice });
  } catch (err: any) {
    console.error('[admin/publish-chapter] error', err);
    return NextResponse.json({ error: err.message || 'Publish failed' }, { status: 500 });
  }
}
